 # Viacheslav Kuznetsov
 # goitneo-python-hw-1-group_1
